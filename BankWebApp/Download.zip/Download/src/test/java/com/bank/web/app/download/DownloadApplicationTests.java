package com.bank.web.app.download;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DownloadApplicationTests {

	@Test
	void contextLoads() {
	}

}
